Packaged for MODx Revolution 
S. Hamblett steve.hamblett@linux.com 18/01/2010