<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7dd2fb1301dc79656881fbd9ff9f36ed',
      'native_key' => 'uncomplicated',
      'filename' => 'modNamespace/9e1e2470c3efa3b07ba8b331f5c62a02.vehicle',
      'namespace' => 'uncomplicated',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '55ae1cfa72a8c5debecade96fdec2959',
      'native_key' => 1,
      'filename' => 'modCategory/2eed7ccc8b814f04b5eb5393f53bd68f.vehicle',
      'namespace' => 'uncomplicated',
    ),
  ),
);