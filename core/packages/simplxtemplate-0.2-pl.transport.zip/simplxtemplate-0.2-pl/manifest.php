<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '62c72c756368cde618c22bb80f4e3ac1',
      'native_key' => 'simplxtemplate',
      'filename' => 'modNamespace/e4cfce9ecb497315a2e8cebd941eca35.vehicle',
      'namespace' => 'simplxtemplate',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2c917ff0e97bf5427bd5495ce6471e18',
      'native_key' => 1,
      'filename' => 'modCategory/edeec75f6a95b08192a93d62e5f1fb1a.vehicle',
      'namespace' => 'simplxtemplate',
    ),
  ),
);