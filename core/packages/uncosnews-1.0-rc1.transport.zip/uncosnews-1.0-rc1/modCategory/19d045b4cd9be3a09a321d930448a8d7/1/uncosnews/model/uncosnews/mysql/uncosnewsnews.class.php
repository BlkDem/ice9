<?php
require_once (dirname(dirname(__FILE__)) . '/uncosnewsnews.class.php');
class UncosNewsNews_mysql extends UncosNewsNews {}