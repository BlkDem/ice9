<?php
class UncosNewsNews extends xPDOSimpleObject {}